# slic-python
基于python实现的slic代码
## RUN

    pip install -r requirements.txt
    python SLIC.py
    python SLIC-D.py
该环境为python2.如果是windows或是linux直接运行即可。
如果是mac os，请注意pip安装库是系统自带的python还是brew下安装的python2，如果是后者，请运行python2 SLIC.py


